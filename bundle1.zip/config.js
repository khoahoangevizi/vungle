var config = {
    rating:'4.5', // Up to 5, decimal points will give a half star
    closeTimer:'TIMER' // TIMER or NOTIMER
}

